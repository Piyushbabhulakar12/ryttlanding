import Index from "../components/Home/Index";

export default function Home() {
  return (
    <>
      <Index />
    </>
  );
}
