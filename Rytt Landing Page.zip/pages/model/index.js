import Index from "../../components/Module/Index";

export default function index() {
  return (
    <>
      <Index />
    </>
  );
}
