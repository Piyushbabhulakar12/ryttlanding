import Index from "../../../components/Catagory/Index";

const Deatils = () => {
  return (
    <>
      <Index />
    </>
  );
};
export default Deatils;
