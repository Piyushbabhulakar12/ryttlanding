import Index from "../../../components/Catagory/Index";

const index = () => {
  return (
    <>
      <Index />
    </>
  );
};
export default index;
