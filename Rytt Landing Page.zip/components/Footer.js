import FacebookOutlinedIcon from "@mui/icons-material/FacebookOutlined";
import InstagramIcon from "@mui/icons-material/Instagram";
import TwitterIcon from "@mui/icons-material/Twitter";
import YouTubeIcon from "@mui/icons-material/YouTube";
import { Box, Container, Grid, Link, Typography } from "@mui/material";

const menulist = [
  {
    title: "Home",
    link: "/",
  },
  {
    title: "About Us",
    link: "/about-us",
  },
  {
    title: "Tools",
    url: "/tools",
  },
  {
    title: "Product",
    url: "/product",
  },
  {
    title: "Technology",
    url: "/technology",
  },
  {
    title: "Service",
    url: "/service",
  },
];

const social = [
  {
    icon: <FacebookOutlinedIcon />,
    url: "/",
  },
  {
    icon: <InstagramIcon />,
    url: "/",
  },
  {
    icon: <TwitterIcon />,
    url: "/",
  },
  {
    icon: <YouTubeIcon />,
    url: "/",
  },
];

const Footer = () => {
  return (
    <>
      <Container>
        <Grid container sx={{ my: "50px" }}>
          <Grid item xs={3}>
            <Typography variant="h5" color="primary" sx={{ fontWeight: "600" }}>
              rytt
            </Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography
              variant="h6"
              sx={{ fontWeight: "600", color: "#343434", fontSize: "19px" }}
            >
              Research
            </Typography>
            {menulist.map((data, index) => (
              <Typography key={index} varient="h6" sx={{ mt: "10px" }}>
                <Link
                  href={data.url}
                  color="tertiary"
                  underline="hover"
                  sx={{ fontWeight: "500", color: "#747474" }}
                >
                  {data.title}
                </Link>
              </Typography>
            ))}
          </Grid>
          <Grid item xs={3}>
            <Typography
              variant="h6"
              sx={{ fontWeight: "600", color: "#343434", fontSize: "19px" }}
            >
              Contact Us
            </Typography>
            <Typography varient="h6" sx={{ mt: "10px" }}>
              <Link
                href="mailto: support@gmail.com"
                color="tertiary"
                underline="hover"
                sx={{ fontWeight: "500", color: "#747474" }}
              >
                Email - support@gmail.com
              </Link>
            </Typography>
            <Typography varient="h6" sx={{ mt: "10px" }}>
              <Link
                href="tel: +91 88 288 88001"
                color="tertiary"
                underline="hover"
                sx={{ fontWeight: "500", color: "#747474" }}
              >
                Phone - +91 88 288 88001
              </Link>
            </Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography
              variant="h6"
              sx={{ fontWeight: "600", color: "#343434", fontSize: "19px" }}
            >
              Social Media
            </Typography>
            {social.data}
            <Box
              sx={{
                display: "flex",
                justifyContent: "left",
                gap: "15px",
                mt: "10px",
              }}
            >
              <FacebookOutlinedIcon sx={{ color: "#343434" }} />
              <InstagramIcon sx={{ color: "#343434" }} />
              <TwitterIcon sx={{ color: "#343434" }} />
              <YouTubeIcon sx={{ color: "#343434" }} />
            </Box>

            <Typography
              variant="h6"
              sx={{
                fontWeight: "600",
                color: "#343434",
                fontSize: "19px",
                mt: "35px",
              }}
            >
              Terms and Conditions
            </Typography>
            <Typography varient="h6" sx={{ mt: "10px" }}>
              <Link
                color="tertiary"
                underline="hover"
                sx={{ fontWeight: "500", color: "#747474" }}
              >
                Our Terms of Use
              </Link>
            </Typography>
            <Typography varient="h6" sx={{ mt: "10px" }}>
              <Link
                color="tertiary"
                underline="hover"
                sx={{ fontWeight: "500", color: "#747474" }}
              >
                Our Privacy and policy
              </Link>
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </>
  );
};
export default Footer;
