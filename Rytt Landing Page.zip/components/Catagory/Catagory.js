import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Link,
  Typography,
} from "@mui/material";
import React from "react";
import CatagoryCard from "./CatagoryCard";
import CatagoryList from "./CatagoryList";

const Catagory = ({ catagory_name }) => {
  const [open, setOpen] = React.useState(true);

  const handleClick = () => {
    setOpen(!open);
  };
  return (
    <>
      <Container sx={{ my: "50px" }}>
        <Typography
          variant="h3"
          component="div"
          color="primary"
          sx={{
            fontWeight: "600",
            fontSize: "35px",
            textAlign: "left",
            py: "15px",
          }}
        >
          Lorem Ipsum is simply dummy {catagory_name}
        </Typography>
        <Typography
          variant="subtitle1"
          component="div"
          sx={{ textAlign: "left" }}
        >
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industrys standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it t Lorem Ipsum is simply dummy text of the printing and
          typesetting industry. Lorem Ipsum has been the industrys standard
          dummy text ever since the 1500s,
        </Typography>

        <Grid container sx={{ py: "50px" }} spacing={2}>
          <Grid item xs={4}>
            <Box
              sx={{
                border: "1px solid #e1e1e1",
                borderRadius: "10px",
                padding: "5px",
              }}
            >
              <CatagoryList />
            </Box>
          </Grid>
          <Grid item xs={8}>
            <Box sx={{ px: "20px" }}>
              <Breadcrumbs aria-label="breadcrumb">
                <Link underline="hover" color="inherit" href="/model">
                  Model
                </Link>
                <Typography color="text.primary">Catagory</Typography>
              </Breadcrumbs>

              <CatagoryCard />
            </Box>
          </Grid>
        </Grid>
      </Container>
    </>
  );
};
export default Catagory;
