import { useRouter } from "next/router";
import Navbar from "../Navbar";
import Catagory from "./Catagory";

const Index = () => {
  const router = useRouter();
  const catagory_name = router.query.catagoryname;
  return (
    <>
      <Navbar />
      <Catagory catagory_name={catagory_name} />
    </>
  );
};
export default Index;
