import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import {
  Collapse,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  ListSubheader,
} from "@mui/material";
import React from "react";

const menuitem = [
  {
    title: "Data 1",
    subobj: {
      subtitle: "data yytr",
      subtitle: "data yytr",
    },
  },
  {
    title: "Data 2",
    subobj: {
      subtitle: "data",
    },
  },
  {
    title: "Data 3",
    subobj: {
      subtitle: "data",
    },
  },
  {
    title: "Data 4",
    subobj: {
      subtitle: "data",
    },
  },
];

const CatagoryList = () => {
  const [openList, setopenList] = React.useState({});

  const handlerListOpen = (el) => {
    console.log("el", el.currentTarget.getAttribute("name"));
    const target = el.currentTarget;
    setopenList((prev) => ({
      ...prev,
      [target.getAttribute("name")]: !prev[target.getAttribute("name")],
    }));
  };
  return (
    <List component={"nav"}>
      <ListSubheader component="div" id="nested-list-subheader">
        Catagory
      </ListSubheader>
      {menuitem.map((page, index) => (
        <List key={index}>
          <ListItem name={page.title} button onClick={handlerListOpen}>
            <ListItemText primary={page.title} />
            {openList[page.title] ? <ExpandLess /> : <ExpandMore />}
          </ListItem>

          <Collapse
            in={openList[page.title]}
            key={index}
            timeout="auto"
            unmountOnExit
          >
            <List component="div" disablePadding>
              <ListItemButton sx={{ pl: 4 }}>
                <ListItemText primary={page.subobj.subtitle} />
              </ListItemButton>
            </List>
          </Collapse>
        </List>
      ))}
    </List>
  );
};
export default CatagoryList;
