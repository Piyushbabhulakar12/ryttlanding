import { Card, Typography } from "@mui/material";

const carddetail = [
  {
    title: " Lorem Ipsum is simply dummy text",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took",
    time: "9 min ago",
  },
  {
    title: " Lorem Ipsum is simply dummy text",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took",
    time: "9 min ago",
  },
  {
    title: " Lorem Ipsum is simply dummy text",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took",
    time: "9 min ago",
  },
  {
    title: " Lorem Ipsum is simply dummy text",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took",
    time: "9 min ago",
  },
];

const CatagoryCard = () => {
  return (
    <>
      {carddetail.map((data, index) => (
        <Card
          key={index}
          sx={{
            padding: "15px",
            boxShadow: "none",
            mt: "15px",
            border: "1px solid #e1e1e1",
          }}
        >
          <Typography
            variant="h6"
            component="div"
            sx={{
              fontWeight: "600",
              fontSize: "25px",
              textAlign: "left",
            }}
          >
            {data.title}
          </Typography>
          <Typography
            variant="subtitle1"
            component="div"
            sx={{ textAlign: "left", fontSize: "14px", mt: "5px" }}
          >
            {data.des}
          </Typography>
          <Typography
            variant="subtitle1"
            component="div"
            sx={{ textAlign: "right", fontSize: "12px", mt: "9px" }}
          >
            {data.time}
          </Typography>
        </Card>
      ))}
    </>
  );
};
export default CatagoryCard;
