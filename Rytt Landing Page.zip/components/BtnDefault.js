import { Button } from "@mui/material";

const BtnDefault = ({ title, url }) => {
  return (
    <>
      <Button
        variant="outlined"
        color="primary"
        sx={{ textTransform: "capitalize", px: "35px" }}
      >
        {title}
      </Button>
    </>
  );
};
export default BtnDefault;
